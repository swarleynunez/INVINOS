# InfoBaginBoxDimensiones

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alto** | **float64** | Alto del bag in box en cm | [optional] [default to null]
**Ancho** | **float64** | Ancho del bag in box en cm | [optional] [default to null]
**Largo** | **float64** | Largo del bag in box en cm | [optional] [default to null]
**Capacidad** | **float64** | Capacidad del bag in box en litros | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

