# Lote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumLote** | **string** |  | [default to null]
**Caducidad** | **string** | Fecha de caducidad | [default to null]
**FechaEnvasado** | **string** | Fecha de envasado | [default to null]
**Url** | **string** | URL de trazabilidad del lote. Con esta se podrá hacer la trazabilidad del lote en la blockchain. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

