# InfoMostoAddQuimica

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Gap** | **float64** | Graduación alcohólica potencial %vol | [optional] [default to null]
**Densidad** | **float64** | Densidad del vino g/ml | [optional] [default to null]
**Otros** | **string** | Otros datos químicos del vino | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

