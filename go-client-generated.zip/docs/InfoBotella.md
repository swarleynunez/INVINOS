# InfoBotella

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TipoStd** | **string** | Tipo de botella | [optional] [default to null]
**TipoOtros** | **string** | Tipo de botella | [optional] [default to null]
**Dimensiones** | [***InfoBotellaDimensiones**](InfoBotella_dimensiones.md) |  | [optional] [default to null]
**Material** | **string** | Material del que está hecha la botella | [optional] [default to null]
**Color** | **string** | Color de la botella | [optional] [default to null]
**Tapn** | **string** | Tipo de tapón de la botella | [optional] [default to null]
**Etiqueta** | [***Etiqueta**](etiqueta.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

