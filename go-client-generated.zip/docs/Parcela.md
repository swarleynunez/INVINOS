# Parcela

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Nombre de la parcela | [default to null]
**Localizacion** | [**[]AnyOfParcelaLocalizacionItems**](.md) | Localización de la parcela | [optional] [default to null]
**Certificados** | [**[]AnyOfParcelaCertificadosItems**](.md) | Certificados de la parcela subidos a IPFS | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

