# IpfSfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpfsId** | **string** | Hash del documento IPFS | [default to null]
**Name** | **string** | Nombre del documento | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

