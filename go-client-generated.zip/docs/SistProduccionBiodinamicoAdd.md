# SistProduccionBiodinamicoAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipo** | **string** | Tipo de certificado | [optional] [default to null]
**Certificado** | [***CertTemplateAdd**](cert_template_add.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

