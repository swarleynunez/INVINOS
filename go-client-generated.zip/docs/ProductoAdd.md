# ProductoAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [default to null]
**Nombre** | **string** | Nombre del producto | [optional] [default to null]
**Tipo** | **string** | Tipo de producto | [optional] [default to null]
**Cantidad** | [***ProductoAddCantidad**](Producto_add_cantidad.md) |  | [default to null]
**Info** | [**[]OneOfProductoAddInfoItems**](.md) | Información sobre el producto, como está hecho, añadas, etc. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

