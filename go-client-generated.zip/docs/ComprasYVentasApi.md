# {{classname}}

All URIs are relative to *https://api.server.test/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddPurchasePost**](ComprasYVentasApi.md#AddPurchasePost) | **Post** /add/purchase | Añadir una compra
[**AddSalePost**](ComprasYVentasApi.md#AddSalePost) | **Post** /add/sale | Añadir una venta

# **AddPurchasePost**
> Compra AddPurchasePost(ctx, body)
Añadir una compra

Añade una compra a la blockchain

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Compra**](Compra.md)| Compra a añadir | 

### Return type

[**Compra**](Compra.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AddSalePost**
> Venta AddSalePost(ctx, body)
Añadir una venta

Añade una venta a la blockchain

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Venta**](Venta.md)| Venta a añadir | 

### Return type

[**Venta**](Venta.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

