# InfoBarrica

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipo** | **string** |  | [optional] [default to null]
**Dimensiones** | [***InfoBarricaDimensiones**](InfoBarrica_dimensiones.md) |  | [optional] [default to null]
**Material** | **string** | Material del que está hecha la barrica | [optional] [default to null]
**Tostado** | **string** | Tostado de la barrica | [optional] [default to null]
**Edad** | **float64** | Edad de la barrica en años | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

