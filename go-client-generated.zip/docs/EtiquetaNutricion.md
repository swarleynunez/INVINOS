# EtiquetaNutricion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VEnergetico** | **float64** | Valor energético del vino en kcal/100ml | [optional] [default to null]
**Alergias** | **string** | Alergias o Intolerancias que puede contener el vino | [optional] [default to null]
**Ingredientes** | **string** | Ingredientes que contiene el vino | [optional] [default to null]
**Declaracion** | **string** | Declaración nutricional del vino | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

