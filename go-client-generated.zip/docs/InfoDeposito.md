# InfoDeposito

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipo** | **string** |  | [optional] [default to null]
**Dimensiones** | [***InfoDepositoDimensiones**](InfoDeposito_dimensiones.md) |  | [optional] [default to null]
**Material** | **string** | Material del que está hecho el depósito | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

