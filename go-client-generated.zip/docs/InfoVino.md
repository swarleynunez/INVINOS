# InfoVino

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Color** | **string** | Tipo de vino según color de vino | [optional] [default to null]
**Quimica** | [***InfoVinoAddQuimica**](InfoVino_add_quimica.md) |  | [optional] [default to null]
**Elaboracion** | **string** | Subtipo de vino según crianza | [optional] [default to null]
**Composicion** | [**[]InfoComponente**](InfoComponente.md) | Variedades de uva que componen el vino y sus añadas | [optional] [default to null]
**Certificados** | [**[]AnyOfInfoVinoCertificadosItems**](.md) | Certificados del vino subidos a IPFS | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

