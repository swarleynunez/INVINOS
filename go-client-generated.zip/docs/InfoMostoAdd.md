# InfoMostoAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipo** | **string** | Tipo de mosto según proceso de elaboración | [optional] [default to null]
**Color** | **string** | Tipo de vino según color de vino | [optional] [default to null]
**Quimica** | [***InfoMostoAddQuimica**](InfoMosto_add_quimica.md) |  | [optional] [default to null]
**Composicion** | [**[]InfoComponente**](InfoComponente.md) | Uvas que componen el mosto | [optional] [default to null]
**Certificados** | [**[]AnyOfInfoMostoAddCertificadosItems**](.md) | Certificados del mosto | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

