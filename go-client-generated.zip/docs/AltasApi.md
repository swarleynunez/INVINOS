# {{classname}}

All URIs are relative to *https://api.server.test/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddCompanyPost**](AltasApi.md#AddCompanyPost) | **Post** /add/company | Añadir una empresa
[**AddContainerPost**](AltasApi.md#AddContainerPost) | **Post** /add/container | Añadir un contenedor
[**AddProductPost**](AltasApi.md#AddProductPost) | **Post** /add/product | Añadir un producto

# **AddCompanyPost**
> Empresa AddCompanyPost(ctx, body)
Añadir una empresa

Añade una empresa a la blockchain

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**EmpresaAdd**](EmpresaAdd.md)| Empresa a añadir | 

### Return type

[**Empresa**](Empresa.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AddContainerPost**
> Contenedor AddContainerPost(ctx, body)
Añadir un contenedor

Añade un contenedor a la blockchain

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Contenedor**](Contenedor.md)| Contenedor a añadir | 

### Return type

[**Contenedor**](Contenedor.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AddProductPost**
> Producto AddProductPost(ctx, body)
Añadir un producto

Añade un producto a la blockchain

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**ProductoAdd**](ProductoAdd.md)| Producto a añadir | 

### Return type

[**Producto**](Producto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

