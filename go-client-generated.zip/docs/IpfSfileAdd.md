# IpfSfileAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**File** | [****os.File**](*os.File.md) |  | [default to null]
**Name** | **string** | Nombre del documento | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

