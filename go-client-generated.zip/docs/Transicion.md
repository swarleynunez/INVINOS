# Transicion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [default to null]
**Tipo** | **string** | Tipo de transición | [default to null]
**Fecha** | **string** | Fecha de la transición | [default to null]
**DeProducto** | [***Producto**](Producto.md) |  | [default to null]
**AProducto** | [***Producto**](Producto.md) |  | [default to null]
**DeContenedor** | [***Contenedor**](Contenedor.md) |  | [default to null]
**AContenedor** | [***Contenedor**](Contenedor.md) |  | [default to null]
**Info** | **string** | Información adicional sobre la transición | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

