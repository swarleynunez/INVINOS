# CertDop

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type_** | **string** | Tipo de certificado | [optional] [default to null]
**Name** | **string** | Nombre de la DOP | [optional] [default to null]
**Certificado** | [***CertTemplate**](cert_template.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

