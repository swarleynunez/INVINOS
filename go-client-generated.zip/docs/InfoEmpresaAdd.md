# InfoEmpresaAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Direccion** | **string** | Dirección de la empresa | [optional] [default to null]
**Telefono** | **string** | Teléfono de la empresa | [optional] [default to null]
**Email** | **string** | Email de la empresa | [optional] [default to null]
**Web** | **string** | Página web de la empresa | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

