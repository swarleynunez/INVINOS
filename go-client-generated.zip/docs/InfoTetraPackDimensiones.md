# InfoTetraPackDimensiones

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alto** | **float64** | Alto del tetra pack en cm | [optional] [default to null]
**Ancho** | **float64** | Ancho del tetra pack en cm | [optional] [default to null]
**Largo** | **float64** | Largo del tetra pack en cm | [optional] [default to null]
**Capacidad** | **float64** | Capacidad del tetra pack en litros | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

