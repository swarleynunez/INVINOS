# Venta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [default to null]
**Fecha** | **string** | Fecha de la venta | [default to null]
**Comprador** | [***Empresa**](Empresa.md) |  | [default to null]
**Producto** | [***ProductoVendido**](Producto_vendido.md) |  | [default to null]
**DeContenedor** | [***Contenedor**](Contenedor.md) |  | [default to null]
**AContenedor** | [***Contenedor**](Contenedor.md) |  | [optional] [default to null]
**Info** | **string** | Información adicional sobre la venta | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

