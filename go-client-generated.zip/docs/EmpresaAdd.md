# EmpresaAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [default to null]
**Nombre** | **string** | Nombre de la empresa | [default to null]
**Cif** | **string** | Código de identificación fiscal | [default to null]
**TipoStd** | **string** | Tipo de empresa | [optional] [default to null]
**TipoOtros** | **string** | Tipo de empresa | [optional] [default to null]
**Info** | [***InfoEmpresaAdd**](InfoEmpresa_add.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

