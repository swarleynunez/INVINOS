# Etiqueta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categoria** | **string** | Categoría del vino: DOP, IGP, Vino de la Tierra, Vino de Mesa | [optional] [default to null]
**Ga** | **float64** | Graduación alcohólica %vol | [optional] [default to null]
**Procedencia** | **string** | Bodega o Cooperativa que produjo el vino | [optional] [default to null]
**Embotellador** | **string** | Nombre del embotellador | [optional] [default to null]
**Lote** | **string** | Lote de producción del vino | [optional] [default to null]
**Nutricion** | [***EtiquetaNutricion**](etiqueta_nutricion.md) |  | [optional] [default to null]
**Fecha** | **string** | Fecha de embotellado del vino | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

