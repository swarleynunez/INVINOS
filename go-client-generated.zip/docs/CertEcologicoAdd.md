# CertEcologicoAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipo** | **string** | Tipo de certificado | [optional] [default to null]
**Name** | **string** | Nombre del certificado | [optional] [default to null]
**Certificadora** | [***CertTemplateAdd**](cert_template_add.md) |  | [optional] [default to null]
**Extra** | [**[]AnyOfcertEcologicoAddExtraItems**](.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

