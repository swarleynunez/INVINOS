# InfoOtros

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descripcion** | **string** | Descripción del producto | [optional] [default to null]
**Composicion** | [**[]InfoComponente**](InfoComponente.md) | Variedades de uva que componen el producto | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

