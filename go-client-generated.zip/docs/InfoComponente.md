# InfoComponente

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Porcentaje** | **float64** | Porcentaje del componente en el producto | [optional] [default to null]
**Uva** | [***InfoUva**](InfoUva.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

