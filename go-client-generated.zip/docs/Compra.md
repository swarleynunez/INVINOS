# Compra

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [default to null]
**Fecha** | **string** | Fecha de la compra | [default to null]
**Vendedor** | [***Empresa**](Empresa.md) |  | [default to null]
**Producto** | [***Producto**](Producto.md) |  | [default to null]
**AContenedor** | [***Contenedor**](Contenedor.md) |  | [default to null]
**Info** | **string** | Información adicional sobre la compra | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

