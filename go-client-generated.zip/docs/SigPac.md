# SigPac

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Provincia** | **float64** | Provincia de la parcela | [default to null]
**Municipio** | **float64** | Municipio de la parcela | [default to null]
**Poligono** | **float64** | Numeración que se le da al polígono | [default to null]
**Parcela** | **float64** | Numeración que se le da a la parcela | [default to null]
**Recinto** | **float64** | Numeración que se le da al recinto | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

