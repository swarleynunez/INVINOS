# {{classname}}

All URIs are relative to *https://api.server.test/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddTransitionPost**](TransicionesApi.md#AddTransitionPost) | **Post** /add/transition | Añadir una transición

# **AddTransitionPost**
> Transicion AddTransitionPost(ctx, body)
Añadir una transición

Añade una transición a la blockchain

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Transicion**](Transicion.md)| Transición a añadir | 

### Return type

[**Transicion**](Transicion.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

