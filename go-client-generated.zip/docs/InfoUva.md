# InfoUva

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Variedad** | **string** | Variedad de uva | [optional] [default to null]
**Aada** | **float64** | Añada de la uva | [optional] [default to null]
**Color** | **string** | Tipo de vino según color de vino | [optional] [default to null]
**Conduccion** | **string** | Tipo de conducción de la uva | [optional] [default to null]
**Vendimia** | **string** | Tipo de vendimia de la uva | [optional] [default to null]
**Certificados** | [**[]AnyOfInfoUvaCertificadosItems**](.md) | Certificados de la uva | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

