# ProductoVendido

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Producto** | [***Producto**](Producto.md) |  | [optional] [default to null]
**Lote** | [***Lote**](Lote.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

