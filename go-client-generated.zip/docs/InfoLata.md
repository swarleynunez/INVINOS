# InfoLata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipo** | **string** |  | [optional] [default to null]
**Dimensiones** | [***InfoLataDimensiones**](InfoLata_dimensiones.md) |  | [optional] [default to null]
**Material** | **string** | Material del que está hecha la lata | [optional] [default to null]
**Etiqueta** | [***Etiqueta**](etiqueta.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

