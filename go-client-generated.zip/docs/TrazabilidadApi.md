# {{classname}}

All URIs are relative to *https://api.server.test/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TraceabilityGet**](TrazabilidadApi.md#TraceabilityGet) | **Get** /traceability | Consultar trazabilidad de un producto

# **TraceabilityGet**
> []Accion TraceabilityGet(ctx, numLote)
Consultar trazabilidad de un producto

Consulta la trazabilidad de un producto

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **numLote** | [**string**](.md)| ID del producto | 

### Return type

[**[]Accion**](Accion.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

