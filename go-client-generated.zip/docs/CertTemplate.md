# CertTemplate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Nombre del certificado | [optional] [default to null]
**Files** | [**[]IpfSfile**](IPFSfile.md) | Certificado subido a IPFS | [optional] [default to null]
**Certificadora** | **string** | Nombre de la certificadora | [optional] [default to null]
**FechaCertificacion** | **string** | Fecha de certificación | [optional] [default to null]
**FechaExpiracion** | **string** | Fecha de expiración del certificado | [optional] [default to null]
**Info** | **string** | Información adicional sobre el certificado | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

